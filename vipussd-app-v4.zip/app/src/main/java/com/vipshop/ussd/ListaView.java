package com.vipshop.ussd;

import android.content.Context;
import android.graphics.Color;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/* Lista de pedidos (fila ou histórico), lida do servidor. */
public class ListaView extends ScrollView {
    private final LinearLayout corpo;
    private final String titulo;
    private final String caminho;

    public ListaView(Context c, String titulo, String caminho) {
        super(c);
        this.titulo = titulo;
        this.caminho = caminho;
        setBackgroundColor(Color.BLACK);
        corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(32, 32, 32, 32);
        addView(corpo);
        carregar();
    }

    private TextView texto(String t, int tamanho, String cor) {
        TextView v = new TextView(getContext());
        v.setText(t);
        v.setTextSize(tamanho);
        v.setTextColor(Color.parseColor(cor));
        v.setPadding(0, 8, 0, 8);
        return v;
    }

    private LinearLayout cartao() {
        LinearLayout c = new LinearLayout(getContext());
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(24, 18, 24, 18);
        c.setBackgroundColor(Color.parseColor("#141414"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 14, 0, 0);
        c.setLayoutParams(lp);
        return c;
    }

    private void adicionarAtualizar() {
        Button b = new Button(getContext());
        b.setText("ATUALIZAR");
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#1A1A1A"));
        b.setOnClickListener(v -> carregar());
        corpo.addView(b);
    }

    private void mostrarMsg(String t, String cor) {
        corpo.removeAllViews();
        adicionarAtualizar();
        corpo.addView(texto(titulo, 20, "#FFFFFF"));
        corpo.addView(texto(t, 14, cor));
    }

    void carregar() {
        if (!Config.pronto(getContext())) {
            mostrarMsg("Indisponível neste aparelho.", "#BBBBBB");
            return;
        }
        mostrarMsg("A carregar...", "#BBBBBB");
        new Thread(() -> {
            try {
                JSONArray arr = new JSONArray(Api.pedir(getContext(), "GET", caminho, null));
                post(() -> mostrar(arr));
            } catch (Exception e) {
                post(() -> mostrarMsg("Não foi possível carregar.", "#E0344B"));
            }
        }).start();
    }

    private void mostrar(JSONArray arr) {
        corpo.removeAllViews();
        adicionarAtualizar();
        corpo.addView(texto(titulo, 20, "#FFFFFF"));
        if (arr.length() == 0) {
            corpo.addView(texto("Sem registos.", 14, "#888888"));
            return;
        }
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault());
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p == null) continue;
            String estado = p.optString("estado", "");
            String cor, nome;
            switch (estado) {
                case "concluido": cor = "#4CD964"; nome = "Concluída"; break;
                case "enviando": cor = "#16D97B"; nome = "A enviar"; break;
                case "pendente": cor = "#FFB62E"; nome = "Na fila"; break;
                case "cancelado": cor = "#E0344B"; nome = "Cancelada"; break;
                default: cor = "#E0344B"; nome = "Erro"; break;
            }
            long data = p.optLong("data", 0);
            String quando = data > 0 ? fmt.format(new Date(data)) : "-";
            LinearLayout caixa = cartao();
            caixa.addView(texto(nome + " · " + quando, 15, cor));
            caixa.addView(texto(p.optInt("mb") + " MB para " + p.optString("numero", "-"), 14, "#CCCCCC"));
            corpo.addView(caixa);
        }
    }
}
