package com.vipshop.ussd;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/* Envio manual: número e quantidade em MB, com confirmação antes de enviar. */
public class EnvioView extends LinearLayout {
    private final EditText numero, quantidade;
    private final TextView estado;

    public EnvioView(Context c) {
        super(c);
        setOrientation(VERTICAL);
        setBackgroundColor(Color.BLACK);
        setPadding(48, 48, 48, 48);

        TextView titulo = new TextView(c);
        titulo.setText("ENVIO MANUAL");
        titulo.setTextSize(20);
        titulo.setTextColor(Color.parseColor("#FFD700"));
        addView(titulo);

        numero = new EditText(c);
        numero.setHint("Número (9 dígitos, ex: 857730743)");
        numero.setTextColor(Color.WHITE);
        numero.setHintTextColor(Color.parseColor("#777777"));
        numero.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        addView(numero);

        quantidade = new EditText(c);
        quantidade.setHint("Quantidade em MB (ex: 512)");
        quantidade.setTextColor(Color.WHITE);
        quantidade.setHintTextColor(Color.parseColor("#777777"));
        quantidade.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        addView(quantidade);

        Button b = new Button(c);
        b.setText("ENVIAR");
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#E0344B"));
        b.setOnClickListener(v -> confirmar());
        addView(b);

        estado = new TextView(c);
        estado.setTextColor(Color.parseColor("#BBBBBB"));
        estado.setPadding(0, 16, 0, 0);
        addView(estado);
    }

    private void confirmar() {
        final String n = numero.getText().toString().trim();
        final String m = quantidade.getText().toString().trim();
        if (!n.matches("\\d{9}") || !m.matches("\\d+")) {
            estado.setText("Número com 9 dígitos e quantidade em MB.");
            return;
        }
        new AlertDialog.Builder(getContext())
                .setMessage("Enviar " + m + " MB para " + n + "?")
                .setPositiveButton("ENVIAR", (d, w) -> enviar(n, m))
                .setNegativeButton("CANCELAR", null)
                .show();
    }

    private void enviar(String n, String m) {
        estado.setText("A enviar...");
        new Thread(() -> {
            try {
                JSONObject o = new JSONObject(Api.pedir(getContext(), "POST", "/app/enviar", n + " " + m));
                String msg = o.optBoolean("ok")
                        ? "Pedido criado. ID: " + o.optString("id") + ". A app do telemóvel vai enviar."
                        : "Não foi possível: " + o.optString("erro");
                post(() -> estado.setText(msg));
            } catch (Exception e) {
                post(() -> estado.setText("Sem ligação ao servidor."));
            }
        }).start();
    }
}
