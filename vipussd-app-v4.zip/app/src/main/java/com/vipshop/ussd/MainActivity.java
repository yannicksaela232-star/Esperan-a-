package com.vipshop.ussd;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/* Sem assinatura: ecrã de ativação. Com assinatura ativa: painel, envio, fila e histórico. */
public class MainActivity extends Activity {
    private static final String[] NOMES = {"PAINEL", "ENVIAR", "FILA", "HISTÓRICO"};
    private FrameLayout raiz;
    private EditText campo;
    private TextView estadoAcesso;

    @Override
    protected void onCreate(Bundle guardado) {
        super.onCreate(guardado);
        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(Color.BLACK);
        setContentView(raiz);
        if (Config.pronto(this)) {
            Intent i = new Intent(this, BridgeService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mostrarTela();
    }

    private void mostrarTela() {
        raiz.removeAllViews();
        if (Config.licencaAtiva(this)) raiz.addView(construirPrincipal());
        else raiz.addView(construirAcesso());
    }

    private LinearLayout construirPrincipal() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setBackgroundColor(Color.BLACK);
        v.addView(capa(260));

        LinearLayout abas = new LinearLayout(this);
        abas.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout corpo = new FrameLayout(this);
        for (int i = 0; i < NOMES.length; i++) {
            final int k = i;
            abas.addView(aba(NOMES[i], x -> mostrarAba(corpo, k)));
        }
        v.addView(abas);
        v.addView(corpo);
        mostrarAba(corpo, 0);
        return v;
    }

    private void mostrarAba(FrameLayout corpo, int k) {
        corpo.removeAllViews();
        switch (k) {
            case 0: corpo.addView(new PainelView(this)); break;
            case 1: corpo.addView(new EnvioView(this)); break;
            case 2: corpo.addView(new ListaView(this, "FILA", "/app/fila")); break;
            default: corpo.addView(new ListaView(this, "HISTÓRICO", "/app/historico")); break;
        }
    }

    private ImageView capa(int alturaDp) {
        ImageView img = new ImageView(this);
        img.setImageResource(R.drawable.capa_vip);
        img.setScaleType(ImageView.ScaleType.FIT_XY);
        int px = (int) (alturaDp * getResources().getDisplayMetrics().density);
        img.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px));
        return img;
    }

    private Button aba(String texto, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(texto);
        b.setTextSize(11);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#1A1A1A"));
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    private LinearLayout construirAcesso() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setBackgroundColor(Color.BLACK);
        v.setPadding(48, 32, 48, 48);

        v.addView(capa(280));

        TextView titulo = new TextView(this);
        titulo.setText("VIP BOT AUTO");
        titulo.setTextSize(22);
        titulo.setTextColor(Color.parseColor("#FFD700"));
        titulo.setPadding(0, 24, 0, 8);
        v.addView(titulo);

        String ate = Config.licencaAte(this);
        TextView sub = new TextView(this);
        sub.setText(!ate.isEmpty() && !Config.licencaAtiva(this)
                ? "A assinatura expirou. Escreve uma nova chave e toca em PEDIR ACESSO."
                : "Escreve o código de acesso ou um pedido (ex: VIP) e toca em PEDIR ACESSO.");
        sub.setTextSize(14);
        sub.setTextColor(Color.parseColor("#BBBBBB"));
        v.addView(sub);

        campo = new EditText(this);
        campo.setHint("Código ou pedido");
        campo.setTextColor(Color.WHITE);
        campo.setHintTextColor(Color.parseColor("#777777"));
        v.addView(campo);

        Button b = new Button(this);
        b.setText("PEDIR ACESSO");
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#E0344B"));
        b.setOnClickListener(x -> enviarAcesso());
        v.addView(b);

        estadoAcesso = new TextView(this);
        estadoAcesso.setTextColor(Color.parseColor("#BBBBBB"));
        estadoAcesso.setPadding(0, 16, 0, 0);
        v.addView(estadoAcesso);
        return v;
    }

    private void enviarAcesso() {
        final String t = campo.getText().toString().trim();
        if (t.isEmpty()) {
            estadoAcesso.setText("Escreve primeiro o código ou o pedido.");
            return;
        }
        estadoAcesso.setText("A enviar...");
        new Thread(() -> {
            try {
                if (t.toUpperCase().startsWith("VIP-")) {
                    JSONObject o = new JSONObject(Api.pedir(this, "POST", "/app/ativar", t));
                    if (o.optBoolean("ok")) {
                        Config.guardarLicenca(this, o.optString("validade"));
                        runOnUiThread(this::mostrarTela);
                    } else {
                        mostrarErro("Não foi possível: " + o.optString("erro"));
                    }
                } else {
                    JSONObject o = new JSONObject(Api.pedir(this, "POST", "/app/pedir", t));
                    mostrarErro(o.optBoolean("ok")
                            ? "Pedido enviado. Aguarde a aprovação. ID: " + o.optString("id")
                            : "Não foi possível enviar o pedido.");
                }
            } catch (Exception e) {
                mostrarErro("Sem ligação ao servidor. Tenta de novo.");
            }
        }).start();
    }

    private void mostrarErro(String t) {
        runOnUiThread(() -> estadoAcesso.setText(t));
    }
}
