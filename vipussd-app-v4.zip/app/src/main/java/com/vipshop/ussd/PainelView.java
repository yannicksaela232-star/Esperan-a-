package com.vipshop.ussd;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/* Painel: estado do bot, saldo de cada SIM e últimos pedidos. Só funciona com token. */
public class PainelView extends ScrollView {
    private final LinearLayout corpo;

    public PainelView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(32, 32, 32, 32);
        addView(corpo);
        carregar();
    }

    private TextView texto(String t, int tamanho, String cor) {
        TextView v = new TextView(getContext());
        v.setText(t);
        v.setTextSize(tamanho);
        v.setTextColor(Color.parseColor(cor));
        v.setPadding(0, 10, 0, 10);
        return v;
    }

    private LinearLayout cartao() {
        LinearLayout c = new LinearLayout(getContext());
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(24, 20, 24, 20);
        c.setBackgroundColor(Color.parseColor("#141414"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 16, 0, 0);
        c.setLayoutParams(lp);
        return c;
    }

    private void adicionarAtualizar() {
        Button b = new Button(getContext());
        b.setText("ATUALIZAR");
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#1A1A1A"));
        b.setOnClickListener(v -> carregar());
        corpo.addView(b);
    }

    private void mostrarMsg(String t, String cor) {
        corpo.removeAllViews();
        adicionarAtualizar();
        corpo.addView(texto(t, 14, cor));
    }

    void carregar() {
        if (!Config.pronto(getContext())) {
            mostrarMsg("Painel indisponível neste aparelho.", "#BBBBBB");
            return;
        }
        mostrarMsg("A carregar...", "#BBBBBB");
        new Thread(() -> {
            try {
                JSONObject r = new JSONObject(Api.pedir(getContext(), "GET", "/app/resumo", null));
                JSONArray h = new JSONArray(Api.pedir(getContext(), "GET", "/app/historico", null));
                post(() -> mostrar(r, h));
            } catch (Exception e) {
                post(() -> mostrarMsg("Não foi possível carregar o painel.", "#E0344B"));
            }
        }).start();
    }

    private void mostrar(JSONObject r, JSONArray h) {
        corpo.removeAllViews();
        adicionarAtualizar();
        corpo.addView(texto("Atualizado às " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()), 12, "#888888"));
        corpo.addView(texto(r.optString("marca", "VIP BOT AUTO"), 22, "#FFFFFF"));

        LinearLayout estadoBot = cartao();
        boolean pausado = r.optBoolean("pausado", false);
        boolean manutencao = r.optBoolean("manutencao", false);
        estadoBot.addView(texto("Estado do bot: " + (pausado ? "EM PAUSA" : "ATIVO")
                + (manutencao ? " · MANUTENÇÃO" : ""), 16, pausado ? "#E0344B" : "#4CD964"));
        JSONObject cont = r.optJSONObject("contagem");
        if (cont != null) {
            estadoBot.addView(texto("Pendentes: " + cont.optInt("pendente", 0)
                    + " · A enviar: " + cont.optInt("enviando", 0)
                    + " · Com erro: " + cont.optInt("erro", 0), 14, "#CCCCCC"));
        }
        corpo.addView(estadoBot);

        int limite = r.optInt("limiteDia", 10);
        JSONArray cart = r.optJSONArray("cartoes");
        if (cart != null) {
            for (int i = 0; i < cart.length(); i++) {
                JSONObject c = cart.optJSONObject(i);
                if (c == null) continue;
                LinearLayout caixa = cartao();
                String megas = c.isNull("megas") ? "sem saldo lido" : c.optInt("megas") + " MB";
                int usadas = c.optInt("usadas", 0);
                caixa.addView(texto("SIM " + c.optInt("sim", i + 1), 16, "#FFFFFF"));
                caixa.addView(texto("Saldo: " + megas, 18, "#4CD964"));
                caixa.addView(texto("Transferências hoje: " + usadas + " de " + limite
                        + " (restam " + Math.max(0, limite - usadas) + ")", 13, "#CCCCCC"));
                corpo.addView(caixa);
            }
        }

        corpo.addView(texto("Últimos pedidos", 18, "#FFFFFF"));
        if (h.length() == 0) {
            corpo.addView(texto("Ainda não há pedidos concluídos.", 14, "#888888"));
        }
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault());
        for (int i = 0; i < h.length(); i++) {
            JSONObject p = h.optJSONObject(i);
            if (p == null) continue;
            String estado = p.optString("estado", "");
            String cor = estado.equals("concluido") ? "#4CD964" : "#E0344B";
            String nomeEstado = estado.equals("concluido") ? "Concluída" : estado.equals("cancelado") ? "Cancelada" : "Erro";
            long data = p.optLong("data", 0);
            String quando = data > 0 ? fmt.format(new Date(data)) : "-";
            String sim = p.isNull("sim") ? "" : " · SIM " + p.optInt("sim");
            LinearLayout caixa = cartao();
            caixa.addView(texto(nomeEstado + " · " + quando, 15, cor));
            caixa.addView(texto(p.optInt("mb") + " MB para " + p.optString("numero", "-") + sim, 14, "#CCCCCC"));
            corpo.addView(caixa);
        }
    }
}
